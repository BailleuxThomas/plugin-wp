<?php
// @error_reporting( E_ALL );
// ini_set( 'display_errors', true );
/**
 * Creates the Submenu2 page for the plugin.
 *
 * @package Custom_Admin_Settings
 */

/**
 * Créer une sous menu pour la page du plugin.
 *
 * Fourni les fonctionnalité nécessaire pour le rendu de la page.
 *
 * @package Custom_Admin_Settings
 */

class Submenu2_Page
{
    /**
     * Cette fonction renvoi un contenu associé à un menu qui assure le rendu.
     */
    private $dir, $page, $nombre2, $dh, $filesizeoctes, $filesize;
    public function fu_fileType($fileType, $fileImg) {
        
        $nombre2 = 0;
        global $dir, $page, $dh, $nombre2, $filesizeoctes, $filesize;

        //  si le dossier pointe existe
        if ( is_dir($dir) ) {
            // print_r($dir)
            
            echo '<form name="ace-list" method="post" action="' . $page . '" style="margin:0 10px;">';
            // si il contient quelque chose
            if ($dh = opendir($dir)) {
                // boucler tant que quelque chose est trouvé
                while (($file = readdir($dh)) !== false) {
                    $filesizeoctes = $dir.'/'.$file;
                    $filesize = (filesize($filesizeoctes) * .0009765625) * .0009765625;
                    // affiche le nom et le type si ce n'est pas un element du systeme
                    // if ($file != '.' && $file != '..') { AFFICHE TOUT
                    //     $nombre2++;
                    $fileSize = $dir . '/' .  $file;
                    if ($file != '.' && $file != '..' && preg_match("#\.$fileType" , $file)) { // Uniquement DOCUMENT TEXT 
                        $nombre2++;
                        echo '<input type="checkbox" name="fichier[]" 
                        value="' . $file . '" />
                        <img src="../Repertoire_utilisateurs/image/' . $fileImg . '.png" height="40"/>
                        <a href="'.$dir.'/'.$file.'" download="'.$file.'">'. $file .' </a>'.round($filesize,3). ' Mb<br>';
                    }
                }
            }else{
                echo "not dir";
                exit;
            }
        }
    }
    public function render2()
    {

        /* Parametrage */


        /* Fin du parametrage */

        // --------------------------- GESTION AFFICHAGE ID + NOM PRENOM -------------------
        echo ('<h1 style="text-align:center;">Gestion CLOUD</h1>');
        echo ('<div style=":width: 80%;border:3px solid black;height:100%;overflow:scroll;">');
        global $dir, $page, $nombre2, $dh, $filesizeoctes, $filesize;
        $root = '../CLOUD/';
        $page = './admin.php?page=FTP+CLOUD';

        $dir ="../CLOUD/";
    

        // ---------------------------------------- GESTION CLOUD ----------------------
    

        // ----------------------------------------FICHIERS TEXTES-----------------------------------
        $this->fu_fileType('(txt?g|txt)$#i', 'txt');
        $this->fu_fileType('(pdf?g|pdf)$#i', 'pdf');
        $this->fu_fileType('(docx?g|docx|doc|dot)$#i', 'docx');
        $this->fu_fileType('(xlsx?g|xlsx|xls)$#i', 'xlsx');

        // ----------------------------------------FICHIERS IMAGES-----------------------------------

         $this->fu_fileType('(png?g|png)$#i', 'png');
         $this->fu_fileType('(jpe?g|jpe|jpeg)$#i', 'jpg');
         $this->fu_fileType('(gif?g|gif|)$#i', 'gif');
         $this->fu_fileType('(bmp?g|bmp|)$#i', 'bmp');

        // ----------------------------------------FICHIERS AUDIO/VIDEO-----------------------------------

         $this->fu_fileType('(avi?g|avi)$#i', 'avi');
         $this->fu_fileType('(mkv?g|mkv)$#i', 'mkv');
         $this->fu_fileType('(mp3?g|mp3)$#i', 'mp3');
        // ----------------------------------------FICHIERS ZIP/RAR-----------------------------------

         $this->fu_fileType('(rar?g|rar)$#i', 'rar');
         $this->fu_fileType('(zip?g|zip)$#i', 'zip');

        echo ("<p style=margin:10px;>Il y a $nombre2 documents <br></p>");
        echo '<input type="submit" name="supprimer" value="supprimer">
                </form>';
            
            // on ferme la connection
            closedir($dh);
            if (isset($_POST['supprimer']) && !is_null($_POST['fichier'])) {
                foreach ($_POST['fichier'] as $fichier_a_supprimer) {
                    if (isset($fichier_a_supprimer)) {
                        if (unlink("$dir/$fichier_a_supprimer")) {
                            echo '<meta http-equiv="Refresh" content="0;' . $page . '">';
                            echo "Le document: $fichier_a_supprimer à bien été supprimé<br/>";
                        }else {
                            echo "Le document: $fichier_a_supprimer n'a pas su être supprimé. Veuillez vous rendre dans le plugin admin/class-Submenu2-page.php<br/>";
                        }
                    }
                }
            }
            ?>
    <form method="POST" name="ace-upload-feature" action="<?php echo $page; ?>" enctype="multipart/form-data" style="margin-top:40px;">
            <input type="file" name="uploaded_file"/><br>
            <input type="submit" name="submit"/> <br>
    </form>
    <?php
        if (isset($_POST['submit'])) {

            $maxSize = 9999999999999999999;
            $validExt = array(
                '.jpg',
                '.jpeg',
                '.gif',
                '.png',
                '.pdf',
                '.rar',
                '.zip',
                '.mp4',
                '.mp3',
                '.avi',
                '.mkv',
                '.txt',
                '.xlsx',
                'xls',
                '.docx',
                '.doc',
                '.dot',
                '.bmp',


            ); /*Ici les formats autorisés*/

            if ($_FILES['uploaded_file']['error'] > 0) {
                echo "Une erreur est survenue lors du transfert";
                die;
            }

            $fileSize = $_FILES['uploaded_file']['size'];

            if ($fileSize > $maxSize) {
                echo "Le document est trop gros!";
                die;
            }

            $fileName = basename($_FILES['uploaded_file']['name']);
            $fileExt = "." . strtolower(substr(strrchr($fileName, '.'), 1));

            if (!in_array($fileExt, $validExt)) {
                echo "Le document n'est pas conforme!";
                die;
            }

            $tmpName = $_FILES['uploaded_file']['tmp_name'];
            //$fileName = basename($_FILES["uploaded_file"]["name"]);
            // $uniqueName = md5(uniqid(rand(), true)); Pour avoir un nom aléatoire
            $resultat = move_uploaded_file( $tmpName, "$dir/$fileName" );

            if ($resultat) {
                echo '<meta http-equiv="Refresh" content="0;' . $page . '">';
                echo "trasnfert terminé";
            }

            /* Tutoriel https://www.youtube.com/watch?v=SfZ0oAiRhCU */
        }
    }
}