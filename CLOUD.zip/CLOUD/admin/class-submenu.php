<?php
/**
 * Creates the Submenu2 item for the plugin.
 *
 * @package Custom_Admin_Settings
 */

/**
 * Créer un sous menu pour le menu.
 *
 * Enregistre un menu sous le menu "Outils".
 *
 * @package Custom_Admin_Settings
 */
class Submenu2
{

    /**
     * A reference the class responsible for render2ing the Submenu2 page.
     *
     * @var Submenu2_Page
     * @access private
     */
    private $Submenu2_page;

    /**
     * Initializer toutes les classes.
     *
     * @param Submenu2_Page $Submenu2_page A reference to the class that render2s the
     * page for the plugin.
     */
    public function __construct($Submenu2_page)
    {
        $this->Submenu2_page = $Submenu2_page;
    }

    /**
     * Ajoute un sous menu dans le menu outils.
     */
    public function init()
    {
        add_action('admin_menu', array($this, 'add_menu_page'));
    }

    /**
     * Creates the Submenu2 item and calls on the Submenu2 Page object to render2
     * the actual contents of the page.
     */
    public function add_menu_page()
    {

        //  add_options_page(
        //  'Page d\'administration',
        //  'Custom Administration Page',
        //  'manage_options',
        //  'custom-admin-page',

        add_menu_page(
            'FTP CLOUD',
            'FTP CLOUD',
            'manage_options',
            'FTP CLOUD',
            array($this->Submenu2_page, 'render2')
        );
    }
}
