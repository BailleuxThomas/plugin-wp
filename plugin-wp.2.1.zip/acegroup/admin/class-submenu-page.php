<?php
@error_reporting( E_ALL );
ini_set( 'display_errors', true );
/**
 * Creates the submenu page for the plugin.
 *
 * @package Custom_Admin_Settings
 */

/**
 * Créer une sous menu pour la page du plugin.
 *
 * Fourni les fonctionnalité nécessaire pour le rendu de la page.
 *
 * @package Custom_Admin_Settings
 */
class Submenu_Page
{
    /**
     * Cette fonction renvoi un contenu associé à un menu qui assure le rendu.
     */
    public function render()
    {

        /* Parametrage */


        /* Fin du parametrage */

        // --------------------------- GESTION AFFICHAGE ID + NOM PRENOM -------------------
        echo ('<h1 style="text-align:center;">Gestion FTP CLIENTS</h1>');
        echo ('<div style=":width: 80%;border:3px solid black;height:100%;overflow:scroll;">');
        global $wpdb;
        $data = $wpdb->get_results("SELECT * FROM {$wpdb->prefix}users");
        $root = '../Repertoire_utilisateurs/';
        $page = './admin.php?page=FTP+CLIENT';


        $espace = ' ';
        $client_selectionne = null;
        foreach ($data as $userData) {
            $ID = $userData->ID . $espace . $userData->display_name;
            $dossier = $root;
            if (!is_dir($dossier . $ID)) {
                mkdir($dossier . $ID);
            }
        }

        $rep_client = "";
        if (isset( $_POST['client_selectionne'] )) {
            $client_selectionne = $_POST['client_selectionne'];            
            $rep_client = $client_selectionne . "/" ;
        }elseif(isset($_GET['rep_client'])) {
            $client_selectionne = $_GET['rep_client'];
        }
        $page .= "&amp;rep_client=".$client_selectionne; 

        echo ' <form name="ace-client" method="post" action="' . $page . '" style="margin:10px;">';
        echo '     <select name="client_selectionne">';
        foreach ($data as $userData) {
            $selected = "";
            $client_dir = $userData->ID . " " . $userData->display_name;
            if($client_dir == $client_selectionne)
                $selected = "selected";

            echo "<option value=\"$client_dir\" $selected>$userData->ID $userData->display_name</option>";

        }
        echo '     </select>';
        echo '     <input type="submit" name="clients">';
        echo ' </form>';

        // ---------------------------------------- GESTION FTP CLIENTS ----------------------
       

        $nombre2 = 0;
        $dir = "../Repertoire_utilisateurs/";

        //  si le dossier pointe existe
        if ( is_dir( $dir.$client_selectionne) ) {
            // print_r($dir.$client_selectionne);

             echo '<form name="ace-list" method="post" action="' . $page . '" style="margin:0 10px;">';

            // si il contient quelque chose
            if ($dh = opendir($dir.$client_selectionne)) {
                // boucler tant que quelque chose est trouvé
                while (($file = readdir($dh)) !== false) {
                    $filesizeoctes = $dir.$client_selectionne.'/'.$file;
                    $filesize = (filesize($filesizeoctes) * .0009765625) * .0009765625;
                
                    // affiche le nom et le type si ce n'est pas un element du systeme
                    // if ($file != '.' && $file != '..') { AFFICHE TOUT
                    //     $nombre2++;

                    /*--------------DOCUMENT TEXTE---------------*/
                    if ($file != '.' && $file != '..' && preg_match('#\.(txt?g|txt)$#i', $file)) { /* Uniquement DOCUMENT TEXT */
                        $nombre2++;
                        echo '<input type="checkbox" name="fichier[]" 
                        value="' . $file . '" />
                        <img src="../Repertoire_utilisateurs/image/txt.png" height="40"/>
                        <a href="'.$dir.$client_selectionne.'/'.$file.'" download="'.$file.'">'. $file .' </a>'.round($filesize,3). ' Mb<br>';
                    }

                    if ($file != '.' && $file != '..' && preg_match('#\.(pdf?g|pdf)$#i', $file)) { /* Uniquement DOCUMENT TEXT */
                        $nombre2++;
                        echo '<input type="checkbox" name="fichier[]" 
                        value="' . $file . '" />
                        <img src="../Repertoire_utilisateurs/image/pdf.png" height="40"/>
                        <a href="'.$dir.$client_selectionne.'/'.$file.'" download="'.$file.'">'. $file .' </a>'.round($filesize,3). ' Mb<br>';
                    }

                    if ($file != '.' && $file != '..' && preg_match('#\.(docx?g|docx|doc|dot)$#i', $file)) { /* Uniquement DOCUMENT TEXT */
                        $nombre2++;
                        echo '<input type="checkbox" name="fichier[]" 
                        value="' . $file . '" />
                        <img src="../Repertoire_utilisateurs/image/docx.png" height="40"/>
                        <a href="'.$dir.$client_selectionne.'/'.$file.'" download="'.$file.'">'. $file .' </a>'.round($filesize,3). ' Mb<br>';
                    }

                    if ($file != '.' && $file != '..' && preg_match('#\.(xlsx?g|xlsx|xls)$#i', $file)) { /*  Uniquement DOCUMENT TEXT */
                        $nombre2++;
                        echo '<input type="checkbox" name="fichier[]" 
                        value="' . $file . '" />
                        <img src="../Repertoire_utilisateurs/image/xlsx.png" height="40"/>
                        <a href="'.$dir.$client_selectionne.'/'.$file.'" download="'.$file.'">'. $file .' </a>'.round($filesize,3). ' Mb<br>';
                    }


                    /*------------------------------------IMAGE-------------------------------------*/
                    if ($file != '.' && $file != '..' && preg_match('#\.(png?g|png)$#i', $file)) { /* Uniquement photo*/
                        $nombre2++;
                        echo '<input type="checkbox" name="fichier[]" 
                        value="' . $file . '" />
                        <img src="../Repertoire_utilisateurs/image/png.png" height="40"/>
                        <a href="'.$dir.$client_selectionne.'/'.$file.'" download="'.$file.'">'. $file .' </a>'.round($filesize,3). ' Mb<br>';
                        
                    }

                    if ($file != '.' && $file != '..' && preg_match('#\.(jpe?g|jpe|jpeg)$#i', $file)) { /* Uniquement photo*/
                        $nombre2++;
                        echo '<input type="checkbox" name="fichier[]" 
                        value="' . $file . '" />
                        <img src="../Repertoire_utilisateurs/image/jpg.png" height="40"/>
                        <a href="'.$dir.$client_selectionne.'/'.$file.'" download="'.$file.'">'. $file .' </a>'.round($filesize,3). ' Mb<br>';
                    }

                    if ($file != '.' && $file != '..' && preg_match('#\.(gif?g|gif|)$#i', $file)) { /* Uniquement photo*/
                        $nombre2++;
                        echo '<input type="checkbox" name="fichier[]" 
                        value="' . $file . '" />
                        <img src="../Repertoire_utilisateurs/image/gif.png" height="40"/>
                        <a href="'.$dir.$client_selectionne.'/'.$file.'" download="'.$file.'">'. $file .' </a>'.round($filesize,3). ' Mb<br>';
                    }

                    if ($file != '.' && $file != '..' && preg_match('#\.(bmp?g|bmp|)$#i', $file)) { /* Uniquement photo*/
                        $nombre2++;
                        echo '<input type="checkbox" name="fichier[]" 
                        value="' . $file . '" />
                        <img src="../Repertoire_utilisateurs/image/bmp.png" height="40"/>
                        <a href="'.$dir.$client_selectionne.'/'.$file.'" download="'.$file.'">'. $file .' </a>'.round($filesize,3). ' Mb<br>';
                    }
                    /*----------------------------FIN IMAGE----------------------------------*/
                    /*----------------------------DOCUMENT AUDIO/VIDEO ----------------------------------*/
                    if ($file != '.' && $file != '..' && preg_match('#\.(avi?g|avi)$#i', $file)) { /* Uniquement AUDIO/VIDEO*/
                        $nombre2++;
                        echo '<input type="checkbox" name="fichier[]" 
                        value="' . $file . '" />
                        <img src="../Repertoire_utilisateurs/image/avi.png" height="40"/>
                        <a href="'.$dir.$client_selectionne.'/'.$file.'" download="'.$file.'">'. $file .' </a>'.round($filesize,3). ' Mb<br>';
                    }

                    if ($file != '.' && $file != '..' && preg_match('#\.(mkv?g|mkv)$#i', $file)) { /* Uniquement AUDIO/VIDEO*/
                        $nombre2++;
                        echo '<input type="checkbox" name="fichier[]" 
                        value="' . $file . '" />
                        <img src="../Repertoire_utilisateurs/image/mkv.png" height="40"/>
                        <a href="'.$dir.$client_selectionne.'/'.$file.'" download="'.$file.'">'. $file .' </a>'.round($filesize,3). ' Mb<br>';
                    }

                    if ($file != '.' && $file != '..' && preg_match('#\.(mp3?g|mp3)$#i', $file)) { /* Uniquement AUDIO/VIDEO*/
                        $nombre2++;
                        echo '<input type="checkbox" name="fichier[]" 
                        value="' . $file . '" />
                        <img src="../Repertoire_utilisateurs/image/mp3.png" height="40"/>
                        <a href="'.$dir.$client_selectionne.'/'.$file.'" download="'.$file.'">'. $file .' </a>'.round($filesize,3). ' Mb<br>';
                    }

                    if ($file != '.' && $file != '..' && preg_match('#\.(mkv?g|mkv)$#i', $file)) { /* Uniquement AUDIO/VIDEO*/
                        $nombre2++;
                        echo '<input type="checkbox" name="fichier[]" 
                        value="' . $file . '" />
                        <img src="../Repertoire_utilisateurs/image/mkv.png" height="40"/>
                        <a href="'.$dir.$client_selectionne.'/'.$file.'" download="'.$file.'">'. $file .' </a>'.round($filesize,3). ' Mb<br>';
                    }
                    /*----------------------------FIN DOCUMENT AUDIO/VIDEO ----------------------------------*/
                    /*----------------------------DOCUMENT ZIP/RAR----------------------------------*/
                    if ($file != '.' && $file != '..' && preg_match('#\.(rar?g|rar)$#i', $file)) { /* Uniquement AUDIO/VIDEO*/
                        $nombre2++;
                        echo '<input type="checkbox" name="fichier[]" 
                        value="' . $file . '" />
                        <img src="../Repertoire_utilisateurs/image/rar.png" height="40"/>
                        <a href="'.$dir.$client_selectionne.'/'.$file.'" download="'.$file.'">'. $file .' </a>'.round($filesize,3). ' Mb<br>';
                    }
                    if ($file != '.' && $file != '..' && preg_match('#\.(zip?g|zip)$#i', $file)) { /* Uniquement AUDIO/VIDEO*/
                        $nombre2++;
                        echo '<input type="checkbox" name="fichier[]" 
                        value="' . $file . '" />
                        <img src="../Repertoire_utilisateurs/image/zip.png" height="40"/>
                        <a href="'.$dir.$client_selectionne.'/'.$file.'" download="'.$file.'">'. $file .' </a>'.round($filesize,3). ' Mb<br>';
                    }
                    /*----------------------------FIN DOCUMENT ZIP/RAR ----------------------------------*/
                }
                echo ("<p style=margin:10px;>Il y a $nombre2 documents <br></p>");
            }else{
                echo "not dir";
                exit;
            }
            echo '<input type="submit" name="supprimer" value="supprimer">
                </form>';

            // on ferme la connection

            closedir($dh);

            if (isset($_POST['supprimer']) && !is_null($_POST['fichier'])) {
                foreach ($_POST['fichier'] as $fichier_a_supprimer) {
                    if (isset($fichier_a_supprimer)) {
                        if (unlink("$dir/$client_selectionne/$fichier_a_supprimer")) {
                            echo '<meta http-equiv="Refresh" content="0;' . $page . '">';
                            echo "Le document: $fichier_a_supprimer à bien été supprimé<br/>";
                        } else {
                            echo "Le document: $fichier_a_supprimer n'a pas su être supprimé. Veuillez vous rendre dans le plugin admin/class-submenu-page.php<br/>";
                        }
                    }
                }
            }
        }
        // -----------------------REQUETE DE DOCUMENT-----------------------        
        
    ?>
    <form method="POST" name="ace-upload" action="<?php echo $page; ?>" enctype="multipart/form-data" style="margin-top:40px;">
            <input type="file" name="uploaded_file"/><br>
            <input type="hidden" name="repertoire_client_selectionne" value=" <?php echo $client_selectionne; ?>" />
            <input type="submit" name="submit"/> <br>
    </form>
    <?php
        if (isset($_POST['submit'])) {

            $maxSize = 9999999999999999999;
            $validExt = array(
                '.jpg',
                '.jpeg',
                '.gif',
                '.png',
                '.pdf',
                '.rar',
                '.zip',
                '.mp4',
                '.mp3',
                '.avi',
                '.mkv',
                '.txt',
                '.xlsx',
                'xls',
                '.docx',
                '.doc',
                '.dot',
                '.bmp',


            ); /*Ici les formats autorisés*/

            if ($_FILES['uploaded_file']['error'] > 0) {
                echo "Une erreur est survenue lors du transfert";
                die;
            }

            $fileSize = $_FILES['uploaded_file']['size'];

            if ($fileSize > $maxSize) {
                echo "Le document est trop gros!";
                die;
            }

            $fileName = basename($_FILES['uploaded_file']['name']);
            $fileExt = "." . strtolower(substr(strrchr($fileName, '.'), 1));

            if (!in_array($fileExt, $validExt)) {
                echo "Le document n'est pas conforme!";
                die;
            }

            $tmpName = $_FILES['uploaded_file']['tmp_name'];
            // $uniqueName = md5(uniqid(rand(), true)); Pour avoir un nom aléatoire
            $resultat = move_uploaded_file( $tmpName, "$dir/$client_selectionne/$fileName" );


            if ($resultat) {
                echo '<meta http-equiv="Refresh" content="0;' . $page . '">';
                echo "trasnfert terminé";
            }

            /* Tutoriel https://www.youtube.com/watch?v=SfZ0oAiRhCU */
        }
    }
}