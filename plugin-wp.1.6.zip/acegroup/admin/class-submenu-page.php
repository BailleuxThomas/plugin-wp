<?php
/**
 * Creates the submenu page for the plugin.
 *
 * @package Custom_Admin_Settings
 */

/**
 * Créer une sous menu pour la page du plugin.
 *
 * Fourni les fonctionnalité nécessaire pour le rendu de la page.
 *
 * @package Custom_Admin_Settings
 */
class Submenu_Page
{
    /**
     * Cette fonction renvoi un contenu associé à un menu qui assure le rendu.
     */
    public function render()
    {

        /* Parametrage */
        copy('.avi.png', '../../Repertoire_utilisateurs/image/avi.png');


        /* Fin du parametrage */

        // --------------------------- GESTION AFFICHAGE ID + NOM PRENOM -------------------
        echo ('<h1 style="text-align:center;">Gestion FTP CLIENTS</h1>');
        echo ('<div style=":width: 80%;border:3px solid black;height:100%;overflow:scroll;">');
        global $wpdb;
        $data = $wpdb->get_results("SELECT * FROM wp_users");
        $root = '../../Repertoire_utilisateurs/';
        $page = './admin.php?page=FTP+CLIENT';

        foreach ($data as $userData) {
            $espace = '_';
            $ID = $userData->ID . $espace . $userData->display_name;
            $dossier = $root;
            if (!is_dir($dossier . $ID)) {
                mkdir($dossier . $ID);
            }
        }

        echo ' <form method="post" action=""' . $page . '"" style="margin:10px;">';
        echo '     <select name="name">';
        foreach ($data as $userData) {
            echo "<option value=$userData->user_nicename>$userData->ID $userData->user_nicename</option>";
            // echo "<option value=$userData->ID>$userData->ID</option>";
        }
        echo '     </select>';
        echo '     <input type="submit" name="clients">';
        echo ' </form>';

        // ---------------------------------------- GESTION FTP CLIENTS ----------------------
        echo '<form method="post" action=""' . $page . '"" style="margin:0 10px;">';

        $nombre2 = 0;
        $dir = "../../Repertoire_utilisateurs/";
        //  si le dossier pointe existe
        if (is_dir($dir)) {

            // si il contient quelque chose
            if ($dh = opendir($dir)) {
                // boucler tant que quelque chose est trouvé
                while (($file = readdir($dh)) !== false) {
                    // affiche le nom et le type si ce n'est pas un element du systeme
                    // if ($file != '.' && $file != '..') { AFFICHE TOUT
                    //     $nombre2++;

                    /*--------------DOCUMENT TEXTE---------------*/
                    if ($file != '.' && $file != '..' && preg_match('#\.(txt?g|txt)$#i', $file)) { /* Uniquement DOCUMENT TEXT */
                        $nombre2++;
                        echo '<input type="checkbox" name="fichier[]" 
                        value="' . $file . '" />
                        <img src="../../Repertoire_utilisateurs/image/txt.png" height="40"/>
                        <a href="../../Repertoire_utilisateurs/' . $file . '" target=_blank>' . $file . '</a><br>';
                    }

                    if ($file != '.' && $file != '..' && preg_match('#\.(pdf?g|pdf)$#i', $file)) { /* Uniquement DOCUMENT TEXT */
                        $nombre2++;
                        echo '<input type="checkbox" name="fichier[]" 
                        value="' . $file . '" />
                        <img src="../../Repertoire_utilisateurs/image/pdf.png" height="40"/>
                        <a href="../../Repertoire_utilisateurs/' . $file . '" target=_blank>' . $file . '</a><br>';
                    }

                    if ($file != '.' && $file != '..' && preg_match('#\.(docx?g|docx|doc|dot)$#i', $file)) { /* Uniquement DOCUMENT TEXT */
                        $nombre2++;
                        echo '<input type="checkbox" name="fichier[]" 
                        value="' . $file . '" />
                        <img src="../../Repertoire_utilisateurs/image/docx.png" height="40"/>
                        <a href="../../Repertoire_utilisateurs/' . $file . '" target=_blank>' . $file . '</a><br>';
                    }

                    if ($file != '.' && $file != '..' && preg_match('#\.(xlsx?g|xlsx|xls)$#i', $file)) { /*  Uniquement DOCUMENT TEXT */
                        $nombre2++;
                        echo '<input type="checkbox" name="fichier[]" 
                        value="' . $file . '" />
                        <img src="../../Repertoire_utilisateurs/image/xlsx.png" height="40"/>
                        <a href="../../Repertoire_utilisateurs/' . $file . '" target=_blank>' . $file . '</a><br>';
                    }


                    /*------------------------------------IMAGE-------------------------------------*/
                    if ($file != '.' && $file != '..' && preg_match('#\.(png?g|png)$#i', $file)) { /* Uniquement photo*/
                        $nombre2++;
                        echo '<input type="checkbox" name="fichier[]" 
                        value="' . $file . '" />
                        <img src="../../Repertoire_utilisateurs/image/png.png" height="40"/>
                        <a href="../../Repertoire_utilisateurs/' . $file . '" target=_blank>' . $file . '</a><br>';
                    }

                    if ($file != '.' && $file != '..' && preg_match('#\.(jpe?g|jpe|jpeg)$#i', $file)) { /* Uniquement photo*/
                        $nombre2++;
                        echo '<input type="checkbox" name="fichier[]" 
                        value="' . $file . '" />
                        <img src="../../Repertoire_utilisateurs/image/jpg.png" height="40"/>
                        <a href="../../Repertoire_utilisateurs/' . $file . '" target=_blank>' . $file . '</a><br>';
                    }

                    if ($file != '.' && $file != '..' && preg_match('#\.(gif?g|gif|)$#i', $file)) { /* Uniquement photo*/
                        $nombre2++;
                        echo '<input type="checkbox" name="fichier[]" 
                        value="' . $file . '" />
                        <img src="../../Repertoire_utilisateurs/image/gif.png" height="40"/>
                        <a href="../../Repertoire_utilisateurs/' . $file . '" target=_blank>' . $file . '</a><br>';
                    }

                    if ($file != '.' && $file != '..' && preg_match('#\.(bmp?g|bmp|)$#i', $file)) { /* Uniquement photo*/
                        $nombre2++;
                        echo '<input type="checkbox" name="fichier[]" 
                        value="' . $file . '" />
                        <img src="../../Repertoire_utilisateurs/image/bmp.png" height="40"/>
                        <a href="../../Repertoire_utilisateurs/' . $file . '" target=_blank>' . $file . '</a><br>';
                    }
                    /*----------------------------FIN IMAGE----------------------------------*/
                    /*----------------------------DOCUMENT AUDIO/VIDEO ----------------------------------*/
                    if ($file != '.' && $file != '..' && preg_match('#\.(avi?g|avi)$#i', $file)) { /* Uniquement AUDIO/VIDEO*/
                        $nombre2++;
                        echo '<input type="checkbox" name="fichier[]" 
                        value="' . $file . '" />
                        <img src="../../Repertoire_utilisateurs/image/avi.png" height="40"/>
                        <a href="../../Repertoire_utilisateurs/' . $file . '" target=_blank>' . $file . '</a><br>';
                    }

                    if ($file != '.' && $file != '..' && preg_match('#\.(mkv?g|mkv)$#i', $file)) { /* Uniquement AUDIO/VIDEO*/
                        $nombre2++;
                        echo '<input type="checkbox" name="fichier[]" 
                        value="' . $file . '" />
                        <img src="../../Repertoire_utilisateurs/image/mkv.png" height="40"/>
                        <a href="../../Repertoire_utilisateurs/' . $file . '" target=_blank>' . $file . '</a><br>';
                    }

                    if ($file != '.' && $file != '..' && preg_match('#\.(mp3?g|mp3)$#i', $file)) { /* Uniquement AUDIO/VIDEO*/
                        $nombre2++;
                        echo '<input type="checkbox" name="fichier[]" 
                        value="' . $file . '" />
                        <img src="../../Repertoire_utilisateurs/image/mp3.png" height="40"/>
                        <a href="../../Repertoire_utilisateurs/' . $file . '" target=_blank>' . $file . '</a><br>';
                    }

                    if ($file != '.' && $file != '..' && preg_match('#\.(mkv?g|mkv)$#i', $file)) { /* Uniquement AUDIO/VIDEO*/
                        $nombre2++;
                        echo '<input type="checkbox" name="fichier[]" 
                        value="' . $file . '" />
                        <img src="../../Repertoire_utilisateurs/image/mkv.png" height="40"/>
                        <a href="../../Repertoire_utilisateurs/' . $file . '" target=_blank>' . $file . '</a><br>';
                    }
 /*----------------------------FIN DOCUMENT AUDIO/VIDEO ----------------------------------*/

                }
                echo ("<p style=margin:10px;>Il y a $nombre2 documents <br></p>");
            }
            echo '<input type="submit" name="supprimer" value="supprimer">
                </form>';

            // on ferme la connection

            closedir($dh);

            if (isset($_POST['supprimer']) && !is_null($_POST['fichier'])) {
                foreach ($_POST['fichier'] as $fichier_a_supprimer) {
                    if (isset($fichier_a_supprimer)) {
                        if (unlink($dir . $fichier_a_supprimer)) {
                            echo '<meta http-equiv="Refresh" content="0;' . $page . '">';
                            echo "Le document: $fichier_a_supprimer à bien été supprimé<br/>";
                        } else {
                            echo "Le document: $fichier_a_supprimer n'a pas su être supprimé. Veuillez vous rendre dans le plugin admin/class-submenu-page.php<br/>";
                        }
                    }
                }
            }
        }
        // -----------------------REQUETE DE DOCUMENT-----------------------
        echo ('<br><br><br><form method="POST" action="' . $page . '" enctype="multipart/form-data">
        <input type="file" name="uploaded_file"/><br>
        <input type="submit" name="submit"/> <br>
        </form>');

        if (isset($_POST['submit'])) {

            $maxSize = 9999999999999999999;
            $validExt = array(
                '.jpg',
                '.jpeg',
                '.gif',
                '.png',
                '.pdf',
                '.rar',
                '.zip',
                '.mp4',
                '.mp3',
                '.avi',
                '.mkv',
                '.txt',
                'xlsx', 'xls',
                'docx', 'doc', 'dot',
                'bmp',


            ); /*Ici les formats autorisés*/

            if ($_FILES['uploaded_file']['error'] > 0) {
                echo "Une erreur est survenue lors du transfert";
                die;
            }

            $fileSize = $_FILES['uploaded_file']['size'];

            if ($fileSize > $maxSize) {
                echo "Le document est trop gros!";
                die;
            }

            $fileName = $_FILES['uploaded_file']['name'];
            $fileExt = "." . strtolower(substr(strrchr($fileName, '.'), 1));

            if (!in_array($fileExt, $validExt)) {
                echo "Le document n'est pas conforme!";
                die;
            }

            $tmpName = $_FILES['uploaded_file']['tmp_name'];
            // $uniqueName = md5(uniqid(rand(), true)); Pour avoir un nom aléatoire
            $uniqueName = $fileName; /* Pour avoir le nom du document bien précis */
            $fileName = "../../Repertoire_utilisateurs/" . $uniqueName;
            $resultat = move_uploaded_file($tmpName, $fileName);

            if ($resultat) {
                echo '<meta http-equiv="Refresh" content="0;' . $page . '">';
                echo "trasnfert terminé";
            }

            /* Tutoriel https://www.youtube.com/watch?v=SfZ0oAiRhCU */
        }
    }
}
