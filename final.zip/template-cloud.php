<?php
/*
Template Name: FTP Cloud
*/


require_once "wp-load.php";
get_header();
class Data2
{   

    private $dir, $page, $nombre2, $dh, $filesizeoctes, $filesize, $data, $espace;

    public function fu_fileType($fileType, $fileImg) {
        
        $nombre2 = 0;
        global $dir, $page, $dh, $nombre2, $filesizeoctes, $filesize, $data, $espace;

        //  si le dossier pointe existe
        if ( is_dir( $dir) ) {
            // si il contient quelque chose
            if ($dh = opendir($dir)) {
                // boucler tant que quelque chose est trouvé
                while (($file = readdir($dh)) !== false) {
                    $filesizeoctes = $dir.'/'.$file;
                    $filesize = (filesize($filesizeoctes) * .0009765625) * .0009765625;
                    // affiche le nom et le type si ce n'est pas un element du systeme
                    // if ($file != '.' && $file != '..') { AFFICHE TOUT
                    //     $nombre2++;
                    $fileSize = $dir. '/' .  $file;
                    if ($file != '.' && $file != '..' && preg_match("#\.$fileType" , $file)) { // Uniquement DOCUMENT TEXT 
                        $nombre2++;
                        echo '<style>.imagefunctionrepertoire{margin-top:20px!important;}</style>
                        <div class="imagefunctionrepertoire">
                        <img src="../'.$dir.'./image/' . $fileImg . '.png" height="30" width="30" />
                        <a href="../'.$dir.'/'.$file.'" download="'.$file.'">'. $file .' </a>'.round($filesize,3). ' Mb<br>
                        </div>';
                    }
                }
            }else{
                echo "not dir";
                exit;
            }
        }
    }
    public function userData()
    {
        echo'
        <head><title>Repertoire Cloud</title></head>
        <style>
        .sidebar{display:none}
        .page_top_wrap,.itemscope{display:none}
        .page_content_wrap{background-image: url("http://plateformehorus.follow-us.net/wp-content/themes/alliance/fw/images/bg/pattern_8.png");}
        </style>';
        echo ('<h1 style="text-align:center;">Repertoire Cloud</h1>');
        echo ('<div style=":width: 100%;height:100%">');
        global $dir, $page, $dh, $nombre2, $filesizeoctes, $filesize, $espace;
        

        $espace = ' ';

        $dir = "./Cloud/";




        // ---------------------------------------- GESTION FTP Cloud ----------------------
       
        // ----------------------------------------FICHIERS TEXTES-----------------------------------
        $this->fu_fileType('(txt?g|txt)$#i', 'txt');
        $this->fu_fileType('(pdf?g|pdf)$#i', 'pdf');
        $this->fu_fileType('(docx?g|docx|doc|dot)$#i', 'docx');
        $this->fu_fileType('(xlsx?g|xlsx|xls)$#i', 'xlsx');

        // ----------------------------------------FICHIERS IMAGES-----------------------------------

         $this->fu_fileType('(png?g|png)$#i', 'png');
         $this->fu_fileType('(jpe?g|jpe|jpeg)$#i', 'jpg');
         $this->fu_fileType('(gif?g|gif|)$#i', 'gif');
         $this->fu_fileType('(bmp?g|bmp|)$#i', 'bmp');

        // ----------------------------------------FICHIERS AUDIO/VIDEO-----------------------------------

         $this->fu_fileType('(avi?g|avi)$#i', 'avi');
         $this->fu_fileType('(mkv?g|mkv)$#i', 'mkv');
         $this->fu_fileType('(mp3?g|mp3)$#i', 'mp3');
        // ----------------------------------------FICHIERS ZIP/RAR-----------------------------------

         $this->fu_fileType('(rar?g|rar)$#i', 'rar');
         $this->fu_fileType('(zip?g|zip)$#i', 'zip');

        echo ("<p style=margin:10px;>Il y a $nombre2 documents <br></p>");



            // on ferme la connection

            closedir($dh);
        }


    }

$userData= new Data2;
$userData->userData();


?>
<?php get_header(); ?>

    <?php
/**
Template Name: FTP Cloud
 */

get_template_part('single');

$vas="0";

?>