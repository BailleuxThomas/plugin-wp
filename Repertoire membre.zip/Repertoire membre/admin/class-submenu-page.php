<?php
// @error_reporting( E_ALL );
// ini_set( 'display_errors', true );
/**
 * Creates the submenu page for the plugin.
 *
 * @package Custom_Admin_Settings
 */

/**
 * Créer une sous menu pour la page du plugin.
 *
 * Fourni les fonctionnalité nécessaire pour le rendu de la page.
 *
 * @package Custom_Admin_Settings
 */

class Submenu_Page
{
    /**
     * Cette fonction renvoi un contenu associé à un menu qui assure le rendu.
     */
    private $client_selectionne, $dir, $page, $nombre2, $dh, $filesizeoctes, $filesize;
    public function fu_fileType($fileType, $fileImg) {
        
        $nombre2 = 0;
        global $dir, $client_selectionne, $page, $dh, $nombre2, $filesizeoctes, $filesize;

        //  si le dossier pointe existe
        if ( is_dir( $dir.$client_selectionne) ) {
            // print_r($dir.$client_selectionne)
            
            echo '<form name="ace-list" method="post" action="' . $page . '" style="margin:0 10px;">';
            // si il contient quelque chose
            if ($dh = opendir($dir.$client_selectionne)) {
                // boucler tant que quelque chose est trouvé
                while (($file = readdir($dh)) !== false) {
                    $filesizeoctes = $dir.$client_selectionne.'/'.$file;
                    $filesize = (filesize($filesizeoctes) * .0009765625) * .0009765625;
                    // affiche le nom et le type si ce n'est pas un element du systeme
                    // if ($file != '.' && $file != '..') { AFFICHE TOUT
                    //     $nombre2++;
                    $fileSize = $dir . $client_selectionne . '/' .  $file;
                    if ($file != '.' && $file != '..' && preg_match("#\.$fileType" , $file)) { // Uniquement DOCUMENT TEXT 
                        $nombre2++;
                        echo '<input type="checkbox" name="fichier[]" 
                        value="' . $file . '" />
                        <img src="../Repertoire_utilisateurs/image/' . $fileImg . '.png" height="40"/>
                        <a href="'.$dir.$client_selectionne.'/'.$file.'" download="'.$file.'">'. $file .' </a>'.round($filesize,3). ' Mb<br>';
                    }
                }
            }else{
                echo "not dir";
                exit;
            }
        }
    }
    public function render()
    {

        /* Parametrage */


        /* Fin du parametrage */

        // --------------------------- GESTION AFFICHAGE ID + NOM PRENOM -------------------
        echo ('<h1 style="text-align:center;">Gestion FTP CLIENTS</h1>');
        echo ('<div style=":width: 80%;border:3px solid black;height:100%;overflow:scroll;">');
        global $wpdb, $dir, $client_selectionne, $page, $nombre2, $dh, $filesizeoctes, $filesize;
        $data = $wpdb->get_results("SELECT * FROM {$wpdb->prefix}users");
        $root = '../Repertoire_utilisateurs/';
        $page = './admin.php?page=FTP+CLIENT';

        $dir ="../Repertoire_utilisateurs/";
        $client_selectionne = null;
        $espace = ' ';

        function copypaste($var1, $var2)
{
        if (file_exists($var1)) {
                echo "Le fichier $var1 existe.";
        } else {
                $index = fopen($var1, 'a+'); // Ouverture d'un fichier en lecture/écriture, en le créant s'il n'existe pas. 
                $ecriture1 = '<?php 
                    echo \'<meta http-equiv="refresh" content="durée;URL='.$var2.'"> \'; 
                    ?>';

                fwrite($index, $ecriture1); // On écrit.
                fclose($index); // On ferme.
        }
}
        foreach ($data as $userData) {
            $ID = $userData->ID . $espace . $userData->display_name;
            $dossier = $root;
             $indexphp = "$dossier/$ID/index.php";
            if (!is_dir($dossier . $ID)) {
                mkdir($dossier . $ID);
                copypaste($indexphp,'../../');
            }
        }

        $rep_client = "";
        if (isset( $_POST['client_selectionne'] )) {
            $client_selectionne = $_POST['client_selectionne'];            
            $rep_client = $client_selectionne . "/" ;
        }elseif(isset($_GET['rep_client'])) {
            $client_selectionne = $_GET['rep_client'];
        }
        $page .= "&amp;rep_client=".$client_selectionne; 

        echo ' <form name="ace-client" method="post" action="' . $page . '" style="margin:10px;">';
        echo '     <select name="client_selectionne">';
        foreach ($data as $userData) {
            $selected = "";
            $client_dir = $userData->ID . " " . $userData->display_name;
            if($client_dir == $client_selectionne)
                $selected = "selected";

            echo "<option value=\"$client_dir\" $selected>$userData->ID $userData->display_name</option>";

        }
        echo '     </select>';
        echo '     <input type="submit" name="clients">';
        echo ' </form>';

        // ---------------------------------------- GESTION FTP CLIENTS ----------------------
    

        // ----------------------------------------FICHIERS TEXTES-----------------------------------
        $this->fu_fileType('(txt?g|txt)$#i', 'txt');
        $this->fu_fileType('(pdf?g|pdf)$#i', 'pdf');
        $this->fu_fileType('(docx?g|docx|doc|dot)$#i', 'docx');
        $this->fu_fileType('(xlsx?g|xlsx|xls)$#i', 'xlsx');

        // ----------------------------------------FICHIERS IMAGES-----------------------------------

         $this->fu_fileType('(png?g|png)$#i', 'png');
         $this->fu_fileType('(jpe?g|jpe|jpeg)$#i', 'jpg');
         $this->fu_fileType('(gif?g|gif|)$#i', 'gif');
         $this->fu_fileType('(bmp?g|bmp|)$#i', 'bmp');

        // ----------------------------------------FICHIERS AUDIO/VIDEO-----------------------------------

         $this->fu_fileType('(avi?g|avi)$#i', 'avi');
         $this->fu_fileType('(mkv?g|mkv)$#i', 'mkv');
         $this->fu_fileType('(mp3?g|mp3)$#i', 'mp3');
        // ----------------------------------------FICHIERS ZIP/RAR-----------------------------------

         $this->fu_fileType('(rar?g|rar)$#i', 'rar');
         $this->fu_fileType('(zip?g|zip)$#i', 'zip');

        echo ("<p style=margin:10px;>Il y a $nombre2 documents <br></p>");
        echo '<input type="submit" name="supprimer" value="supprimer">
                </form>';
            
            // on ferme la connection
            closedir($dh);
            if (isset($_POST['supprimer']) && !is_null($_POST['fichier'])) {
                foreach ($_POST['fichier'] as $fichier_a_supprimer) {
                    if (isset($fichier_a_supprimer)) {
                        if (unlink("$dir/$client_selectionne/$fichier_a_supprimer")) {
                            echo '<meta http-equiv="Refresh" content="0;' . $page . '">';
                            echo "Le document: $fichier_a_supprimer à bien été supprimé<br/>";
                        }else {
                            echo "Le document: $fichier_a_supprimer n'a pas su être supprimé. Veuillez vous rendre dans le plugin admin/class-submenu-page.php<br/>";
                        }
                    }
                }
            }
            ?>
    <form method="POST" name="ace-upload" action="<?php echo $page; ?>" enctype="multipart/form-data" style="margin-top:40px;">
            <input type="file" name="uploaded_file"/><br>
            <input type="hidden" name="repertoire_client_selectionne" value=" <?php echo $client_selectionne; ?>" />
            <input type="submit" name="submit"/> <br>
    </form>
    <?php
        if (isset($_POST['submit'])) {

            $maxSize = 9999999999999999999;
            $validExt = array(
                '.jpg',
                '.jpeg',
                '.gif',
                '.png',
                '.pdf',
                '.rar',
                '.zip',
                '.mp4',
                '.mp3',
                '.avi',
                '.mkv',
                '.txt',
                '.xlsx',
                'xls',
                '.docx',
                '.doc',
                '.dot',
                '.bmp',


            ); /*Ici les formats autorisés*/

            if ($_FILES['uploaded_file']['error'] > 0) {
                echo "Une erreur est survenue lors du transfert";
                die;
            }

            $fileSize = $_FILES['uploaded_file']['size'];

            if ($fileSize > $maxSize) {
                echo "Le document est trop gros!";
                die;
            }

            $fileName = basename($_FILES['uploaded_file']['name']);
            $fileExt = "." . strtolower(substr(strrchr($fileName, '.'), 1));

            if (!in_array($fileExt, $validExt)) {
                echo "Le document n'est pas conforme!";
                die;
            }

            $tmpName = $_FILES['uploaded_file']['tmp_name'];
            //$fileName = basename($_FILES["uploaded_file"]["name"]);
            // $uniqueName = md5(uniqid(rand(), true)); Pour avoir un nom aléatoire
            $resultat = move_uploaded_file( $tmpName, "$dir/$client_selectionne/$fileName" );

            if ($resultat) {
                echo '<meta http-equiv="Refresh" content="0;' . $page . '">';
                echo "trasnfert terminé";
            }

            /* Tutoriel https://www.youtube.com/watch?v=SfZ0oAiRhCU */
        }
    }
}